// for (var i=0; i<256; i++)
//   {
//     console.log(i);
//   }




//   for (var x = 1; x <= 255; x += 2) { 
//     console.log(x);
//   }




// var sum = 0;
//   for (var x = 0; x <= 255; x += 1) {
//     sum = sum + x;
//     console.log(x, sum);
//   }




// var numbers = [2,3,5,7,9,10,14];
// numbers.forEach(function(numbers) {
//   console.log(numbers);
// });





// var numbers = [2,233,25,7,99,10,14,3];
    
// var maxValue = Math.max.apply(null, numbers);
// console.log(maxValue);





// arry = [2,233,25,7,99,10,14,3];

// function calculateAverage(array) {
//     var total = 0;
//     var count = 0;

//     array.forEach(function(item, index) {
//         total += item;
//         count++;
//     });

//     return total / count;
// }
// console.log(calculateAverage(arry));




// for (var i=0; i<=256; i++)
//   {
//     if (i%2 !==0)
//       console.log(i);
//   }




// var square = [2,233,25,7,99,10,14,3].map(function(value){
// 	return Math.pow(value,2);
// });

// console.log(square);