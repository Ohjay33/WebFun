<script>
function hideButton(x)
 {
  x.style.display = 'none';
 }
</script>